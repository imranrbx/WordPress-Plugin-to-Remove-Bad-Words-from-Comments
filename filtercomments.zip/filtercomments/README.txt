=== Filter Comments ===
Contributors: itsmeleo
Tags: Comments, Filter Comments, Plugin
Requires at least: 1.0
Tested up to: 4.6

A small plugin to remove un-necessary and not needed words from Comments

== Description ==
This plugin will help you to easily remove the text in comments which you don\'t allow, specially bad words, so you can type as many words as you want, separate with | sign.


== Installation ==
If you are downloading from Plugin repository then you can simply upload it from Admin panel using add new plugin
if you downloaded the plugin from GitHub repository then better use FTP and transfer the folder to PLUGINS folder.

after installation simply activate and you will see Filter Comments Menu in the dashboard, use it to filter comments text.